mkdir /storage/emulated/0/Telegram-老爺制作
rm -rf  /data/data/com.tencent.ig/files
rm -rf /data/data/com.tencent.ig/app_crashrecord
#dd /data/media/0/老爺制作
touch /data/data/com.tencent.ig/files
touch /data/data/com.tencent.ig/app_crashrecord
